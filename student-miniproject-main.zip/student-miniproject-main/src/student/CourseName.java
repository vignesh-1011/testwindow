package student;

public class CourseName {
	    private String[] courseName={"C","Java","J2EE","Spring","Hibernate"};

		public String[] getCourseName() {
			return courseName;
		}

		public void setCourseName(String[] courseName) {
			this.courseName = courseName;
		}	
	}


